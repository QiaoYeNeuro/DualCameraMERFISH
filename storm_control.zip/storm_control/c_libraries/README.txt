
Pre-compiled DLLs for 64 bit Windows.

This is also where the compiled versions of the C libraries / programs are placed.
